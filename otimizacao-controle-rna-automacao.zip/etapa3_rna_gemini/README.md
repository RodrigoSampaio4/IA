# Etapa 3 — Inteligência Evolutiva com Rede Neural Artificial

## 1. Contextualização

Nas etapas anteriores, o projeto já possuía sensores definidos e uma lógica de decisão baseada em regras especialistas com apoio interpretativo da API do Gemini.

Nesta Etapa 3, foi adicionada uma camada de aprendizado de máquina utilizando uma Rede Neural Artificial. O objetivo é permitir que o agente aprenda padrões a partir dos dados dos sensores e utilize essa previsão para alimentar a lógica da Etapa 2.

## 2. Abordagem escolhida

A abordagem escolhida foi a **Opção A — Redes Neurais Artificiais (RNA)**.

Essa escolha foi feita porque uma RNA permite classificar situações com base nos dados dos sensores e demonstrar aprendizado por meio de métricas como acurácia e curva de perda. Assim, o sistema deixa de depender apenas de regras manuais e passa a utilizar uma camada de previsão.

## 3. Fluxo do sistema

```text
Sensores da Etapa 1
        ↓
Rede Neural Artificial
        ↓
Classificação da situação
        ↓
Lógica especialista da Etapa 2
        ↓
Acionamento dos atuadores
        ↓
Gemini API interpreta a decisão
```

## 4. Sensores utilizados

Foram utilizados dados simulados referentes aos sensores definidos no projeto:

- Inclinação
- Radiação
- Rugosidade

A partir desses dados, a RNA classifica a situação como:

- Seguro
- Atenção
- Perigo

## 5. Integração com a Etapa 2

A saída da Rede Neural Artificial alimenta uma lógica especialista simples:

- Se a situação for **Seguro**, o sistema mantém a operação normal.
- Se a situação for **Atenção**, o sistema reduz a velocidade e monitora os sensores.
- Se a situação for **Perigo**, o sistema aciona o modo de emergência.

Após essa decisão, o resultado pode ser enviado para a API do Gemini para gerar uma explicação interpretativa da decisão tomada.

## 6. Métricas de desempenho

O notebook gera:

- Acurácia do modelo
- Relatório de classificação
- Matriz de confusão
- Gráfico da curva de perda, indicando a evolução do aprendizado da rede neural

## 7. Comparação antes e depois

Antes da Etapa 3, o sistema dependia apenas de regras fixas.

Depois da Etapa 3, o sistema passa a utilizar uma Rede Neural Artificial para prever a situação do ambiente antes de aplicar a lógica especialista. Isso torna o agente mais adaptável, pois ele passa a considerar padrões aprendidos nos dados.

## 8. Como rodar o código

1. Abra o arquivo `Etapa_3_RNA_Gemini.ipynb` no Google Colab.
2. Execute as células na ordem.
3. Verifique os gráficos e métricas gerados.
4. Para usar a API Gemini, adicione sua chave na variável `GEMINI_API_KEY`.
5. Execute a célula de integração final.

## 9. Bibliotecas utilizadas

- numpy
- pandas
- matplotlib
- scikit-learn
- google-generativeai, opcional para integração com Gemini

## 10. Checklist da entrega

- [x] Notebook Google Colab com treinamento da RNA.
- [x] Dados simulados baseados nos sensores da Etapa 1.
- [x] Integração entre RNA e lógica especialista da Etapa 2.
- [x] Geração de gráfico de desempenho.
- [x] Comparação entre sistema antes e depois do aprendizado.
- [x] README atualizado.
- [x] Espaço preparado para integração com Gemini API.
